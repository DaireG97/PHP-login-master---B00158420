<?php
function escape($data) {
    if ($data !== null && is_string($data)) {
        $data = htmlspecialchars($data, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8");
        $data = trim($data);
        $data = stripslashes($data);
        return $data;
    } else {
        return $data; // Return the original value if it's null or not a string
    }
}