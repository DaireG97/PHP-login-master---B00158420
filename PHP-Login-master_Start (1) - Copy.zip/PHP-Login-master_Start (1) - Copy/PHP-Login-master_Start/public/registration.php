<?php
if (isset($_POST['submit'])) {

    try {
        require '../common.php';
        require_once '../src/DBconnect.php';
        $new_user = array(
            "username" => escape($_POST['username']),
            "password" => escape($_POST['password']),

        );
        $sql = sprintf("INSERT INTO `%s` (`%s`) VALUES (:%s)", "users",
            implode("`, `", array_keys($new_user)),
            implode(", :", array_keys($new_user))
        );

        $statement = $connection->prepare($sql);
        $statement->execute($new_user);
    } catch(PDOException $error) {
        echo $sql . "<br>" . $error->getMessage();
    }
}

if (isset($_POST['submit']) && $statement)
{
    echo $new_user['username']. ' successfully added';
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Registration</title>
</head>
<body>
<div class="container">
    <div class="header clearfix">
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contacts.php">Contact</a></li>
                <li><a href="registration.php">Register</a></li>
                <li><a href="public.php">Public</a></li>
            </ul>
        </nav>
    </div>
<link rel="stylesheet" type="text/css" href="../css/signin.css">
<link rel="stylesheet" type="text/css" href="../css/stylesheet.css">
<h2>User Registration</h2>
<form method="post" action="">
    <label for="username">Username:</label><br>

    <input type="text" id="username" name="username"><br><br>

    <label for="password">Password:</label><br>

    <input type="password" id="password" name="password"><br><br>

    <input type="submit" name="submit" value="Register">
</form>
</body>
</html>